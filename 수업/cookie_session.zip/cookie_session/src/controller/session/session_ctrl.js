const index = (req, res) => {
    res.render("session/index");
}

module.exports = { index };